import React from 'react';
import Screen from "./screen/Screen";

const App = () => <Screen></Screen>

export default App;